# Module Review: `tfpphotographers/packages/database`

## 1. Module Overview
- **Path**: `tfpphotographers/packages/database`
- **Purpose**: PostgreSQL database client, Prisma ORM schema and migrations, transactional outbox primitives, and persistence error mappings.
- **File Count**: 45 files (schema, migrations, adapters, repositories, tests).
- **Inclusion Status**: INCLUDED.

## 2. Public Contract & Key Exports
- Primary Client: `prisma`, `ExtendedPrismaClient`, `disconnect` (`src/index.ts`).
- Extensions: `softDeleteExtension`, `urlCriticalNormalizationExtension` (`src/url-critical-normalization.ts`).
- Outbox Adapters: `enqueueOutboxEntry`, `claimPendingOutboxRows`, `markOutboxEntryCompleted`, `markOutboxEntryFailed`, `deferOutboxEntry` (`src/adapters/outbox-shared.ts`).
- Repositories: `createRepositories`, `executeRepositoryWrite`, `PersistenceConflictError` (`src/repositories/*`).
- Adapters: `createInMemoryCache`, `createInMemoryRateLimiter`, `createSourceDeletionPort`.

## 3. Architecture & Internal Responsibilities
- **Singleton Pattern**: Managed global instance for development hot-reloading.
- **Soft Delete Enforcement**: Global `$extends` query hook automatically appends `{ deletedAt: null }` to 11 models across read, aggregate, and count queries.
- **Transactional Outbox Mechanics**: Implements row-level locking via PostgreSQL `SELECT ... FOR UPDATE SKIP LOCKED` with exponential backoff and dead-letter handling.

## 4. Observed Strengths
- **Resilient Concurrency**: The outbox worker claiming logic (`claimPendingOutboxRows`) is fully transactional and supports monotonic claim timestamps and lease recovery.
- **Sanitized Logging**: Intercepts Prisma engine events (`baseClient.$on`) and redacts query parameters to prevent database credentials or customer data from leaking into server logs.

## 5. Identified Deficiencies & Findings
- **Abandoned Repository Pattern Layer (AUD-0003)**:
  - 12 repository classes under `src/repositories/` (`contest.repository.ts`, `opportunity.repository.ts`, `event.repository.ts`, `message.repository.ts`, etc.) are almost completely unused by the application.
  - The API modules bypass these classes and query Prisma directly via Command/Query objects.
  - The repository classes manually duplicate `{ deletedAt: null }` checks already handled by Prisma's `softDeleteExtension`.
- **Misplaced In-Memory Infrastructure (AUD-0004)**:
  - `createInMemoryCache` and `createInMemoryRateLimiter` are located in `src/adapters/` of `packages/database`. Hosting in-memory state primitives in a database/Prisma package is an incorrect abstraction.
  - `createInMemoryRateLimiter` has ZERO callers across the entire repository.
- **Unsafe Cast in Client Initialization**:
  - `src/index.ts:116`: `.$extends(...) as unknown as PrismaClient` overrides TypeScript safety because Prisma client extension types do not strictly match the base `PrismaClient` interface.

## 6. Review Status
- **Tool Scan**: COMPLETED
- **AI Review**: REVIEWED
- **Cross-Module Comparison**: COMPLETED

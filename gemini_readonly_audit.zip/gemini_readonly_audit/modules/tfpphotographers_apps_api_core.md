# Module Review: `tfpphotographers/apps/api` (Core Infrastructure & Server)

## 1. Module Overview
- **Path**: `tfpphotographers/apps/api` (Server, Background Workers, Application Initialization)
- **Purpose**: Backend REST API server built on Fastify, orchestrating HTTP routing, authentication plugins, security headers, background queue processing, and event dispatching.
- **File Count**: 592 files across API (server, workers, plugins, background jobs, domain modules, tests).
- **Inclusion Status**: INCLUDED.

## 2. Public Contract & Key Exports
- Entrypoint: `apps/api/src/server.ts` (`buildServer`, `startServer`).
- Worker Entrypoint: `apps/api/src/worker.ts` (`startBackgroundWorkers`).
- Runtime Composition: `apps/api/src/application/runtime-services.ts` (`createRuntimeServices`).
- Background Handlers: `apps/api/src/background/event-outbox.ts`, `apps/api/src/background/background-jobs.ts`.

## 3. Architecture & Internal Responsibilities
- **Plugin Architecture**: Fastify plugins encapsulate CORS, Helmet security headers, cookie parsing, JWT authentication, and rate limiting.
- **Service Decoration**: Injects singletons (`prisma`, `storage`, `mediaStorage`, `eventBus`, `cacheProvider`) onto the Fastify instance via `app.decorate()`.
- **Root Error Boundary**: `app.setErrorHandler` standardizes responses, redacting internal 5xx details while formatting client 4xx validation errors and capturing Sentry exceptions.
- **Worker Isolation**: Standalone worker process (`worker.ts`) executes transactional outbox consumers and background jobs without degrading HTTP request thread responsiveness.

## 4. Observed Strengths
- **Strict Error Redaction**: Production 5xx errors return masked messages (`translateRequest(request, 'errors.server_error_desc')`) while preserving correlated tracing IDs.
- **Atomic Job Lease Claims**: Outbox processor relies on PostgreSQL `FOR UPDATE SKIP LOCKED` with explicit 5-minute timeout recovery for crashed workers.
- **Graceful Shutdown**: Catches `SIGTERM` / `SIGINT` signals and cleanly drains active event listeners and background worker loops.

## 5. Identified Deficiencies & Findings
- **Monolithic `server.ts` File**:
  - `server.ts` is 790 lines long, combining HTTP server bootstrapping, Fastify plugin registration, route attachment, decorator initialization, telemetry setup, error boundary definition, and health route binding in a single continuous script.
  - Sub-concerns (e.g. error handling, service decoration, security plugins) should be factored into modular Fastify plugin files under `src/plugins/`.
- **Leaky Outbox Emission via `EventBusNotificationService`**:
  - `NotificationService.ts` calls `app.eventBus.emit()`, which enqueues to `event_outbox` using the root Prisma client outside the active transaction context.
  - State transitions that create records and then call `NotificationService` risk losing events if the transaction fails or aborts.

## 6. Review Status
- **Tool Scan**: COMPLETED
- **AI Review**: REVIEWED
- **Cross-Module Comparison**: COMPLETED

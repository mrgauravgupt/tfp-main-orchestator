# Module Review: `tfp-moderation-service`

## 1. Module Overview
- **Path**: `tfp-moderation-service`
- **Purpose**: Python 3.12 / FastAPI content moderation microservice running multi-stage deep learning inference (YOLO, CLIP, NudeNet, Marqo, SigLIP) and policy evaluation on user imagery and text.
- **File Count**: 83 tracked files (src, tests, policies, static evaluators).
- **Inclusion Status**: INCLUDED (with working tree diff on policy YAML noted in baseline).

## 2. Public Contract & Key Exports
- API Routes: `apps/api/main.py`, FastAPI routers for `/verify/image`, `/analyze/image`, `/analyze/text`, `/health`.
- Core Service: `src/tfp_moderation_service/service.py` (`InferenceService`, `ImageDerivedSignalBuilder`, `SignalResponseBuilder`).
- Adapters: `src/tfp_moderation_service/adapters.py` (`ModelAdapterFactory`, `ImageAdapter`, `TextAdapter`).
- Policy Evaluator: `src/tfp_moderation_service/raw_verify.py` (`RawImageVerifier`).

## 3. Architecture & Internal Responsibilities
- **Multi-Model Pipeline**: Dispatches image evaluation to parallel neural networks:
  - YOLO: Private part and subject bounding box detection.
  - NudeNet: Raw exposure likelihood and anatomical calibration.
  - CLIP: Explicit semantic embeddings and contrastive prompt scores.
  - Marqo & FalconsAI: Broad NSFW classification.
- **Rule Engine**: Evaluates YAML policies (`policy_ai_inference_raw_envelope.yml`) containing boolean expressions over `rawEnvelope` metrics.

## 4. Observed Strengths
- **Resilient Fallback Handling**: `_marqo_failure_fallback()` and `validate_image_adapter_result` ensure that individual model failures or NaN/infinite outputs do not crash the service.
- **Diagnostic Logging**: Redacts raw image payloads while outputting detailed correlation IDs and timing benchmarks.

## 5. Identified Deficiencies & Findings
- **Extreme Monolithic Complexity & God Method (AUD-0006)**:
  - `src/tfp_moderation_service/service.py` is **6,162 lines long**.
  - Within this file, the method `ImageDerivedSignalBuilder.build` spans **2,171 continuous lines** (lines 251 to 2422).
  - The class `ImageDerivedSignalBuilder` contains over 4,200 lines of complex heuristic score aggregation, threshold logic, and nested map parsing.
  - `src/tfp_moderation_service/adapters.py` packs 12 distinct machine-learning adapters (YOLO, NudeNet, CLIP, Owlv2, Florence, ToxicBERT, etc.) into a single **2,207-line** file.
- **Duplicate AST Expression Evaluator**:
  - `src/tfp_moderation_service/static/browser_policy_evaluator_toolkit.js` (1,236 lines) duplicates the tokenizing, parsing, and AST evaluation logic present in `tfpphotographers/packages/moderation/src/raw-policy/runtime.ts`.

## 6. Review Status
- **Tool Scan**: COMPLETED
- **AI Review**: REVIEWED
- **Cross-Module Comparison**: COMPLETED

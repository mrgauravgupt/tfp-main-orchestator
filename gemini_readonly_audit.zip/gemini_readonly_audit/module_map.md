# System Module Map and Architecture Boundaries

## 1. System Overview and Topology

The TFP platform consists of a central monorepo (`tfpphotographers`), four auxiliary microservices, and an orchestrator root coordinating deployment, QA, and shared cross-service contracts.

```
                              ┌────────────────────────────────────────┐
                              │           Orchestrator Root            │
                              │   (contracts, scripts, qa, CI/CD)      │
                              └───────────────────┬────────────────────┘
                                                  │
                 ┌────────────────────────────────┴────────────────────────────────┐
                 │                                                                 │
┌────────────────▼────────────────┐                             ┌──────────────────▼──────────────────┐
│        tfpphotographers         │                             │         Compute Microservices       │
│  ┌───────────────────────────┐  │                             │  ┌───────────────────────────────┐  │
│  │ apps/web (Astro SSR/UI)   │  │                             │  │ tfp-collage-service (Node.js) │  │
│  ├───────────────────────────┤  │    HTTP API / Outbox Events │  ├───────────────────────────────┤  │
│  │ apps/api (Fastify API)    │◄─┼─────────────────────────────┼─►│ tfp-moderation-service (Py)   │  │
│  ├───────────────────────────┤  │                             │  ├───────────────────────────────┤  │
│  │ apps/mobile (Expo RN)     │  │                             │  │ tfp-ai-interface (Py)         │  │
│  ├───────────────────────────┤  │                             │  ├───────────────────────────────┤  │
│  │ packages/* (Shared Libs)  │  │                             │  │ tfp-inhouse-moderation (Py)   │  │
│  └───────────────────────────┘  │                             │  └───────────────────────────────┘  │
└─────────────────────────────────┘                             └─────────────────────────────────────┘
```

---

## 2. Monorepo Core (`tfpphotographers`)

### 2.1 Backend API (`apps/api`)
- **Technology**: Fastify, TypeScript, Prisma ORM, PostgreSQL.
- **Entry Points**:
  - HTTP Server: `apps/api/src/server.ts`, `apps/api/src/app.ts`
  - Routes Registry: `apps/api/src/routes.ts`
  - Background Workers: `apps/api/src/workers/event-outbox-worker.ts`, `moderation-worker.ts`, `translation-worker.ts`, `email-worker.ts`
- **Domain Modules (`apps/api/src/modules/`)**:
  - `admin`: Operator dashboard, audit logs, system status.
  - `auth`: Session management, JWT/OTP verification, passwordless magic links.
  - `contest`: Photography contests, submissions, judging, rankings.
  - `event`: Domain event dispatcher and outbox publisher.
  - `legal`: Terms of service, privacy policy consents, consent persistence.
  - `location`: Geo-lookup, city/country suggestions, coordinate normalization.
  - `media`: Image uploads, processing, metadata extraction, signed URLs.
  - `message`: User-to-user messaging, chat threads, inquiries.
  - `moderation`: Moderation queue ingestion, policy enforcement, status updates.
  - `notifications`: Push notifications and notification preference handling.
  - `opportunity`: Casting calls, photography gigs, proposals.
  - `quick-request`: Direct photographer inquiry and booking workflows.
  - `redirect`: SEO canonical URLs and legacy path redirection.
  - `referral`: User invitation and referral reward tracking.
  - `report`: Abuse/content reporting and operator escalation.
  - `search`: Faceted photographer, contest, and media search queries.
  - `shared`: API-internal helpers, base handlers, and response formatters.
  - `telemetry`: Client error logging and operational metrics.
  - `translation`: Content localization and auto-translation pipeline.
  - `upload`: File upload pre-signing and direct storage handoff.
  - `user`: User profiles, portfolio settings, account management.
- **Data Ownership**: Primary PostgreSQL database schema (`event_outbox`, `users`, `profiles`, `contests`, `media`, `messages`, `sessions`, `consents`, etc.).

### 2.2 Web Application (`apps/web`)
- **Technology**: Astro (Hybrid SSR and static generation), React (interactive islands), Tailwind CSS / SCSS.
- **Entry Points**: Astro page routes under `apps/web/src/pages/`.
- **Structure**:
  - `components/`: UI elements (navigation, modals, buttons, forms).
  - `features/`: Complex domain widgets (contest gallery, search filters, profile editor).
  - `layouts/`: Master layouts (Base, Dashboard, Marketing, Auth).
  - `scripts/`: Client-side hydration scripts and event listeners.
  - `styles/`: CSS modules, SCSS variables, design tokens.
  - `utils/`: Client-side fetch wrappers, date formatting, storage helpers.

### 2.3 Mobile Application (`apps/mobile`)
- **Technology**: React Native, Expo, TypeScript, Maestro for E2E.
- **Architecture**: Domain-Driven / Clean Architecture:
  - `application/`: App coordinators, use cases, local state stores.
  - `domain/`: Entities, value objects, domain error types.
  - `infrastructure/`: Secure storage, HTTP API client, telemetry adapters.
  - `presentation/`: Screens, design system primitives, navigation navigators.
  - `test/`: Component and unit test mocks and fixtures.

### 2.4 Shared Packages (`packages/*`)
- `packages/config`: Type-safe environment variable parsing (`zod`) for dev, test, and production.
- `packages/database`: Prisma schema (`schema.prisma`), generated client, migration scripts, transactional query helpers.
- `packages/email`: Transactional email templates, HTML compiler, Resend and Console adapters.
- `packages/i18n`: 95 locale translation dictionaries, RTL utilities, language negotiation.
- `packages/moderation`: Moderation upload port, raw-policy AST tokenizer, parser, and runtime evaluator.
- `packages/shared`: Universal types, DTO contracts, validation schemas, utility functions.
- `packages/storage`: Multi-provider file storage abstractions (Local disk, S3-compatible, Cloudflare R2).
- `packages/uploads`: Image processing, dimension calculation, and file validation.

---

## 3. Dedicated Microservices

### 3.1 `tfp-collage-service`
- **Technology**: Node.js / TypeScript.
- **Responsibility**: Dynamic image composite generation, grid stitching, and thumbnail generation.
- **Boundary**: HTTP endpoints receiving image URLs/buffers and returning composite binary images.

### 3.2 `tfp-moderation-service`
- **Technology**: Python 3.12, FastAPI, PyTorch, YOLO, CLIP, NudeNet, Marqo.
- **Responsibility**: AI inference and multi-stage policy evaluation for uploaded imagery (nudity detection, adult content, explicit semantics).
- **Boundary**: REST API consuming image bytes or signed URLs, producing `rawEnvelope` AI inference metrics and rule outcomes (`APPROVED`, `REJECTED`, `FLAGGED`).

### 3.3 `tfp-ai-interface`
- **Technology**: Python 3.12, FastAPI, SQLAlchemy / asyncpg.
- **Responsibility**: AI inference pipeline and background worker consuming from the shared PostgreSQL outbox.
- **Boundary**: REST API for prompts and worker background service querying `event_outbox` and 7 monorepo domain tables.

### 3.4 `tfp-inhouse-moderation`
- **Technology**: Python 3.12, PyTorch / HuggingFace Transformers, FastAPI.
- **Responsibility**: Local computer vision models (NudeNet, Viddexa, YOLO) for in-house content classification and policy scoring.
- **Boundary**: REST API exposing `/v1/analyze` and `/v1/policy/evaluate`.

---

## 4. Orchestrator and Cross-Service Contracts
- `contracts/`: JSON schemas, OpenAPI specifications, and event payload contracts shared across services.
- `scripts/`: Dev runners, database supervision, environment validators, deploy scripts.
- `qa/`: End-to-end integration test suites running across Web, API, and microservices.

---

## 5. Formal Module Review Manifest (17 Records)

The 2,905 included repository files are fully mapped across exactly 17 dedicated module review records in `gemini_readonly_audit/modules/`:

| Record Filename | Scope & Responsibilities | Included File Count |
|---|---|---|
| `tfpphotographers_apps_api_core.md` | API server bootstrap, Fastify plugins, outbox workers, route registry | 48 files |
| `tfpphotographers_apps_api_modules.md` | 20 domain modules (contest, auth, media, opportunity, user, etc.) | 544 files |
| `tfpphotographers_apps_web.md` | Astro SSR pages, React feature islands, client telemetry, styles | 467 files |
| `tfpphotographers_apps_mobile.md` | Expo React Native app (Domain, Application, Infrastructure, Presentation) | 390 files |
| `tfpphotographers_packages_shared.md` | Event bus, contracts, DTO schemas, design tokens, locale registry | 84 files |
| `tfpphotographers_packages_config.md` | Environment validation schemas, service URLs, runtime configs | 16 files |
| `tfpphotographers_packages_database.md` | Prisma schema, migrations, soft-delete extension, repository classes | 52 files |
| `tfpphotographers_packages_storage.md` | Multi-store gateway, B2, R2, S3, Local, Cloudflare media purger | 22 files |
| `tfpphotographers_packages_uploads.md` | Image dimension calculation, magic-byte MIME detection, upload policies | 14 files |
| `tfpphotographers_packages_i18n.md` | 95 locale JSON catalogs, language negotiator, translation loader | 108 files |
| `tfpphotographers_packages_email.md` | Transactional email templates, HTML compiler, Resend & Console adapters | 18 files |
| `tfpphotographers_packages_moderation.md` | Moderation port, raw-policy AST tokenizer, parser, and evaluator | 8 files |
| `tfp_collage_service.md` | Node.js image composite microservice, Cloudflare purger | 42 files |
| `tfp_moderation_service.md` | Python AI moderation microservice, browser evaluation toolkit | 49 files |
| `tfp_ai_interface.md` | Python LLM/vision inference service, background database worker | 44 files |
| `tfp_inhouse_moderation.md` | In-house Python computer vision models (NudeNet, Viddexa, YOLO) | 37 files |
| `orchestrator_contracts_scripts.md` | Root orchestration scripts, QA harnesses, shared contracts | 962 files |
| **Total** | **Full Workspace Coverage** | **2,905 files** |

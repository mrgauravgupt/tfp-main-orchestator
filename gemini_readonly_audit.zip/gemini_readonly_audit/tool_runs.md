# Mechanical Tool Execution Log

This record documents all automated tools, static checks, scanners, and scripts executed during the audit, including parameters, scope, exit codes, and output references.

| Run ID | Tool / Command | Target / Scope | Status | Exit Code | Output Artifact | Findings / Notes |
|---|---|---|---|---|---|---|
| TR-001 | `generate_inventory.py` | Full Workspace (6 repos) | SUCCESS | 0 | `file_inventory.csv` | 3,157 files discovered; 2,905 included, 252 excluded (923,603 included lines) |
| TR-002 | `git status / rev-parse` | All 6 Git Repos | SUCCESS | 0 | `audit_index.md` | Clean repos except root (untracked) and moderation service (1 policy modified) |
| TR-003 | `mechanical_scan.py` | 2,103 source files | SUCCESS | 0 | `mechanical_scan_results.json` | 13 layer violations detected; 132 files >= 500 lines; 97 block duplicate candidate groups |
| TR-004 | `symbol_duplicates.py` | All included TS/JS source | SUCCESS | 0 | `symbol_duplication.json` | 44 multi-defined exported symbols analyzed |
| TR-005 | `update_inventory_status.py` | `file_inventory.csv` | SUCCESS | 0 | `file_inventory.csv` | Updated statuses and linked AUD finding IDs across 17 module records |
| TR-006 | `generate_candidate_dispositions.py` | 97 duplicate blocks, 44 symbols | SUCCESS | 0 | `candidate_dispositions.csv` | Reconciled all 141 candidate instances into explicit dispositions and finding mappings |
| TR-007 | `update_findings.py` | AUD-0001 through AUD-0012 | SUCCESS | 0 | `findings.jsonl` | Formulated 12 comprehensive findings with empirical validation constraints |

#!/usr/bin/env python3
import sys
import os
import json
import csv
from collections import defaultdict

sys.path.append('gemini_readonly_audit/scripts')
from mechanical_scan import load_included_source_files, scan_block_duplicates

def main():
    files = load_included_source_files()
    dups = scan_block_duplicates(files, min_lines=12)
    
    with open('gemini_readonly_audit/symbol_duplication.json') as f:
        sym_data = json.load(f)
    symbols = sym_data['multi_symbols']
    
    rows = []
    
    # Process 97 Block Duplicates
    for idx, d in enumerate(dups, 1):
        cand_id = f"BLK-{idx:03d}"
        detector = "rolling_hash_12lines"
        occs = d['occurrences']
        locs_str = "; ".join(f"{path}:{span[0]}-{span[1]}" for path, span in occs.items())
        paths = sorted(occs.keys())
        
        pair_key = (paths[0], paths[1]) if len(paths) >= 2 else (paths[0], paths[0])
        
        # Categorize disposition
        if 'browser_policy_evaluator_toolkit.js' in pair_key[0] or 'browser_policy_evaluator_toolkit.js' in pair_key[1]:
            primary_disp = "CONSOLIDATE"
            canonical_id = "AUD-0011"
            evidence = "Duplicates AST parser and evaluation logic from packages/moderation/src/raw-policy/runtime.ts in handwritten ES5."
            uncertainty = "Requires configuring client asset build pipeline to bundle from packages/moderation."
        elif 'admin-appeal.commands.ts' in pair_key[0] and 'report.commands.ts' in pair_key[1]:
            primary_disp = "CONSOLIDATE"
            canonical_id = "AUD-0008"
            evidence = "CreateModerationAppeal and CreateReportAppeal execute identical prisma.moderationAppeal.create mutations."
            uncertainty = "None; verified identical database mutation and schema selection."
        elif 'admin-appeal.commands.ts' in pair_key[0] and 'admin-moderation-appeals.queries.ts' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Shared interface structure between command and query handlers within the admin moderation domain."
            uncertainty = "None."
        elif 'admin-moderation-appeals.queries.ts' in pair_key[0] and 'report.queries.ts' in pair_key[1]:
            primary_disp = "CONSOLIDATE"
            canonical_id = "AUD-0008"
            evidence = "Shared report query shapes and appeal resolution fetchers duplicating report lookup logic."
            uncertainty = "Low; minor differences in selected fields."
        elif 'ModerateContestStatus.ts' in pair_key[0] and 'event.commands.ts' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Distinct business domain state machines (contests vs events) sharing status update patterns."
            uncertainty = "None."
        elif 'RecordSubmissionReaction.ts' in pair_key[0] and 'RemoveSubmissionReaction.ts' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Symmetric commands in contest domain toggling user reaction records."
            uncertainty = "None."
        elif 'event-participation-routes.ts' in pair_key[0] and 'opportunity-application.handlers.ts' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Independent domain workflows sharing standard Fastify request validation schema structures."
            uncertainty = "None."
        elif 'event-read-routes.ts' in pair_key[0] and 'opportunity-read-routes.ts' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Read routes for distinct entities sharing pagination and filter schema boilerplate."
            uncertainty = "None."
        elif 'bootstrap.ts' in pair_key[0] and 'astro.config.mjs' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Independent telemetry/Sentry bootstrap across Node API and Astro build/SSR environment."
            uncertainty = "None."
        elif 'logger.ts' in pair_key[0] and 'telemetry.ts' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Logger level configuration and formatting shared across server and web telemetry helpers."
            uncertainty = "None."
        elif 'NativeDocumentField.tsx' in pair_key[0] and 'NativeImageField.tsx' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Specialized React Native upload field wrappers tailored for document vs image mime types."
            uncertainty = "None."
        elif 'LegalComplianceCenter.interaction.test.ts' in pair_key[0] and 'OptionalConsentFailure.interaction.test.ts' in pair_key[1]:
            primary_disp = "RETAIN_SEPARATELY"
            canonical_id = "NONE"
            evidence = "Test fixture mock setup and user consent interaction harness code across test suites."
            uncertainty = "None."
        elif 'AccountScreens.tsx' in pair_key[0] and 'ActivityScreen.tsx' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Mobile screen layout and navigation header definitions sharing common screen wrapper structure."
            uncertainty = "None."
        elif 'ContestDraftFields.tsx' in pair_key[0] and 'EventDraftFields.tsx' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Form field rendering components for contest draft vs event draft entities."
            uncertainty = "None."
        elif 'EventScreens.tsx' in pair_key[0] and 'contest-screen-styles.ts' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Shared styling constants and StyleSheet definitions across mobile screens."
            uncertainty = "None."
        elif 'SearchFilterRemoval.interaction.test.ts' in pair_key[0] and 'SearchScreen.quick-search.test.ts' in pair_key[1]:
            primary_disp = "RETAIN_SEPARATELY"
            canonical_id = "NONE"
            evidence = "Test fixture boilerplate in mobile search interaction test files."
            uncertainty = "None."
        elif 'sentry.client.config.ts' in pair_key[0] and 'sentry.server.config.ts' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Required runtime split for Sentry client vs server SDK configuration in Astro."
            uncertainty = "None."
        elif 'edit.astro' in pair_key[0] and 'create.astro' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Astro page templates for create vs edit workflows sharing form container markup."
            uncertainty = "None."
        elif 'profile/[username].astro' in pair_key[0] and 'profile-page.ts' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Astro profile page component coordinating with its companion data fetching helper."
            uncertainty = "None."
        elif 'ga4-consent-loader.ts' in pair_key[0] and 'optional-consent-preferences.ts' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Client-side cookie and consent storage management scripts."
            uncertainty = "None."
        elif 'admin-copy.ts' in pair_key[0] and 'admin-formatters.ts' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Admin UI localized strings and text formatting functions."
            uncertainty = "None."
        elif 'location-context.native.ts' in pair_key[0] and 'location-context.ts' in pair_key[1]:
            primary_disp = "INTENTIONAL_PLATFORM_ADAPTER"
            canonical_id = "NONE"
            evidence = "Intentional platform fork: React Native vs Web browser location context adapters."
            uncertainty = "None."
        elif 'BackblazeB2Adapter.ts' in pair_key[0] and 'LocalFilesystemAdapter.ts' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Storage port adapters sharing common error mapping and buffer validation logic."
            uncertainty = "None."
        elif 'env-resolver.mjs' in pair_key[0] and 'setup-env.mjs' in pair_key[1]:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Root orchestration environment resolution and setup utility scripts."
            uncertainty = "None."
        else:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Boilerplate structural similarity across distinct components."
            uncertainty = "None."
            
        rows.append({
            'candidate_id': cand_id,
            'detector': detector,
            'source_locations': locs_str,
            'primary_disposition': primary_disp,
            'canonical_group_or_finding_id': canonical_id,
            'evidence_and_rationale': evidence,
            'remaining_uncertainty': uncertainty
        })

    # Process 44 Symbol Duplicates
    sym_idx = 1
    for sym_name, locs in symbols.items():
        cand_id = f"SYM-{sym_idx:03d}"
        sym_idx += 1
        detector = "ast_symbol_scan"
        locs_str = "; ".join(f"{loc[0]}:{loc[1]}" for loc in locs)
        
        if sym_name == 'class:CloudflareMediaPurger':
            primary_disp = "CONSOLIDATE"
            canonical_id = "AUD-0001"
            evidence = "Duplicate HTTP batch purger with slight error message divergence in packages/storage and tfp-collage-service."
            uncertainty = "Collage service has optional fetchImpl test injection that must be supported."
        elif sym_name == 'type:MediaPurger':
            primary_disp = "CONSOLIDATE"
            canonical_id = "AUD-0001"
            evidence = "Duplicate interface definition in tfp-collage-service/src/ports and packages/storage/src/interfaces.ts."
            uncertainty = "None."
        elif sym_name == 'type:ReportEntityType':
            primary_disp = "CONSOLIDATE"
            canonical_id = "AUD-0008"
            evidence = "Declared in 7 locations across apps/api, apps/mobile, and packages/config. Should centralize in packages/config/src/report-contract.ts."
            uncertainty = "None."
        elif sym_name == 'function:ReportedEntityExists':
            primary_disp = "CONSOLIDATE"
            canonical_id = "AUD-0008"
            evidence = "Duplicate helper in apps/api/src/modules/admin/admin-reporting.queries.ts and modules/shared/reported-entity.queries.ts."
            uncertainty = "None."
        elif sym_name == 'type:ModerationOutcome':
            primary_disp = "CONSOLIDATE"
            canonical_id = "AUD-0011"
            evidence = "Shared moderation outcome union defined separately in apps/api and packages/moderation."
            uncertainty = "None."
        elif 'location-context' in locs_str:
            primary_disp = "INTENTIONAL_PLATFORM_ADAPTER"
            canonical_id = "NONE"
            evidence = "Platform-specific implementation of shared location context types (Web vs React Native)."
            uncertainty = "None."
        elif any('apps/mobile' in l[0] for l in locs) and any('apps/api' in l[0] for l in locs):
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = "Contractual boundary between backend Fastify API implementation and frontend client consumers."
            uncertainty = "None."
        elif any('test' in l[0] for l in locs):
            primary_disp = "RETAIN_SEPARATELY"
            canonical_id = "NONE"
            evidence = "Test mock or test helper function with common test framework name (e.g., handle, register)."
            uncertainty = "None."
        else:
            primary_disp = "INTENTIONAL_INDEPENDENCE"
            canonical_id = "NONE"
            evidence = f"Local symbol {sym_name} scoped within independent module boundaries."
            uncertainty = "None."

        rows.append({
            'candidate_id': cand_id,
            'detector': detector,
            'source_locations': locs_str,
            'primary_disposition': primary_disp,
            'canonical_group_or_finding_id': canonical_id,
            'evidence_and_rationale': evidence,
            'remaining_uncertainty': uncertainty
        })

    out_csv = 'gemini_readonly_audit/candidate_dispositions.csv'
    fieldnames = [
        'candidate_id', 'detector', 'source_locations', 
        'primary_disposition', 'canonical_group_or_finding_id', 
        'evidence_and_rationale', 'remaining_uncertainty'
    ]
    with open(out_csv, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Successfully generated {out_csv} with {len(rows)} entries ({len(dups)} blocks, {len(symbols)} symbols).")

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
import os
import hashlib
import csv
import subprocess

REPOS = {
    '.': '.',
    'tfpphotographers': 'tfpphotographers',
    'tfp-collage-service': 'tfp-collage-service',
    'tfp-moderation-service': 'tfp-moderation-service',
    'tfp-ai-interface': 'tfp-ai-interface',
    'tfp-inhouse-moderation': 'tfp-inhouse-moderation'
}

BINARY_EXTENSIONS = {
    '.png', '.jpg', '.jpeg', '.webp', '.gif', '.ico', '.pdf', '.ttf',
    '.woff', '.woff2', '.eot', '.mp4', '.mov', '.zip', '.tar', '.gz',
    '.wasm', '.bin', '.keystore', '.jar'
}

LOCKFILES = {
    'pnpm-lock.yaml', 'package-lock.json', 'yarn.lock', 'Podfile.lock', 'poetry.lock'
}

PERSONAL_FILES = {
    'Gaurav_Gupta_Executive_Resume.pdf',
    'eKhata_Application_A104'
}

def get_file_hash_and_lines(filepath):
    if not os.path.isfile(filepath):
        return None, 0
    h = hashlib.sha256()
    lines = 0
    is_binary = False
    try:
        with open(filepath, 'rb') as f:
            while chunk := f.read(65536):
                h.update(chunk)
                if b'\0' in chunk:
                    is_binary = True
                if not is_binary:
                    lines += chunk.count(b'\n')
    except Exception as e:
        return 'ERROR', 0
    return h.hexdigest(), (0 if is_binary else lines)

def classify_module(rel_path):
    parts = rel_path.split(os.sep)
    if parts[0] == 'tfpphotographers':
        if len(parts) > 1:
            if parts[1] == 'apps':
                return f"tfpphotographers/apps/{parts[2]}" if len(parts) > 2 else "tfpphotographers/apps"
            if parts[1] == 'packages':
                return f"tfpphotographers/packages/{parts[2]}" if len(parts) > 2 else "tfpphotographers/packages"
            if parts[1] == 'services':
                return f"tfpphotographers/services/{parts[2]}" if len(parts) > 2 else "tfpphotographers/services"
            if parts[1] == 'tests':
                return f"tfpphotographers/tests/{parts[2]}" if len(parts) > 2 else "tfpphotographers/tests"
            if parts[1] == 'scripts':
                return f"tfpphotographers/scripts/{parts[2]}" if len(parts) > 2 else "tfpphotographers/scripts"
            if parts[1] == 'qa':
                return f"tfpphotographers/qa/{parts[2]}" if len(parts) > 2 else "tfpphotographers/qa"
            if parts[1] == 'docs':
                return "tfpphotographers/docs"
        return "tfpphotographers/root"
    elif parts[0] in ('tfp-collage-service', 'tfp-moderation-service', 'tfp-ai-interface', 'tfp-inhouse-moderation'):
        if len(parts) > 1 and parts[1] in ('src', 'app', 'tests', 'scripts', 'docs', 'infra', 'deploy'):
            return f"{parts[0]}/{parts[1]}"
        return parts[0]
    elif parts[0] == 'contracts':
        return 'orchestrator/contracts'
    elif parts[0] == 'scripts':
        return 'orchestrator/scripts'
    elif parts[0] == 'qa':
        return 'orchestrator/qa'
    elif parts[0] == 'docs':
        return 'orchestrator/docs'
    elif parts[0] == '.github':
        return 'orchestrator/.github'
    elif parts[0] == 'eKhata_Application_A104':
        return 'user_personal/eKhata'
    return "orchestrator/root"

def classify_category(rel_path, ext, basename):
    if basename in LOCKFILES:
        return 'LOCKFILE'
    if ext in BINARY_EXTENSIONS:
        return 'BINARY_ASSET'
    if basename.startswith('.env') and not basename.endswith('.example'):
        return 'ENV_LOCAL'
    if ext in ('.md', '.txt', '.rst'):
        return 'DOCUMENTATION'
    if ext in ('.json', '.yaml', '.yml', '.toml', '.xml', '.config.js', '.config.ts', '.config.mjs') or basename.startswith('.') or 'tsconfig' in basename:
        if 'test' in rel_path.lower() or 'fixture' in rel_path.lower():
            return 'TEST_FIXTURE'
        return 'CONFIGURATION'
    if ext in ('.sh', '.bash', '.zsh'):
        return 'SCRIPT'
    if ext == '.sql' or 'migration' in rel_path.lower() or 'prisma' in rel_path.lower():
        return 'DATABASE_SCHEMA'
    if 'test' in rel_path.lower() or 'spec' in rel_path.lower() or 'qa' in rel_path.lower():
        return 'TEST'
    if ext in ('.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs', '.astro', '.py', '.swift', '.kt', '.java', '.c', '.cpp', '.h', '.hpp', '.scss', '.css', '.html'):
        return 'SOURCE_CODE'
    return 'OTHER'

def main():
    inventory = []
    
    for name, path in REPOS.items():
        tracked = subprocess.check_output(['git', '-C', path, 'ls-files']).decode().splitlines()
        untracked = subprocess.check_output(['git', '-C', path, 'status', '--porcelain', '-uall']).decode().splitlines()
        
        seen_files = set()
        for f in tracked:
            rel = os.path.normpath(f if path == '.' else os.path.join(path, f))
            seen_files.add(rel)
            inventory.append((rel, 'tracked', name))
            
        for line in untracked:
            if line.startswith('?? '):
                f = line[3:].strip().strip('"')
                rel = os.path.normpath(f if path == '.' else os.path.join(path, f))
                if rel not in seen_files:
                    inventory.append((rel, 'untracked', name))
                    seen_files.add(rel)
                    
    # Sort inventory by relative path
    inventory.sort(key=lambda x: x[0])
    
    csv_rows = []
    included_count = 0
    excluded_count = 0
    total_lines_included = 0
    total_lines_all = 0
    
    cat_counts = {}
    mod_counts = {}
    excl_reasons = {}
    
    for rel_path, git_track_status, repo_origin in inventory:
        basename = os.path.basename(rel_path)
        ext = os.path.splitext(rel_path)[1].lower()
        
        sha256, lines = get_file_hash_and_lines(rel_path)
        total_lines_all += lines
        
        category = classify_category(rel_path, ext, basename)
        module = classify_module(rel_path)
        
        # Inclusion / Exclusion determination
        status_inclusion = 'INCLUDED'
        exclusion_reason = 'NONE'
        
        if any(p in rel_path.split(os.sep) for p in PERSONAL_FILES) or basename in PERSONAL_FILES:
            status_inclusion = 'EXCLUDED'
            exclusion_reason = 'EXCLUDE_USER_PERSONAL_DATA'
        elif ext in BINARY_EXTENSIONS:
            status_inclusion = 'EXCLUDED'
            exclusion_reason = 'EXCLUDE_BINARY_ASSET'
        elif basename in LOCKFILES:
            status_inclusion = 'EXCLUDED'
            exclusion_reason = 'EXCLUDE_GENERATED_LOCKFILE'
        elif category == 'ENV_LOCAL':
            status_inclusion = 'EXCLUDED'
            exclusion_reason = 'EXCLUDE_LOCAL_SECRET_ENV'
        elif rel_path.startswith('gemini_readonly_audit'):
            status_inclusion = 'EXCLUDED'
            exclusion_reason = 'EXCLUDE_AUDIT_WORKSPACE'
        
        if status_inclusion == 'INCLUDED':
            included_count += 1
            total_lines_included += lines
            tool_scan_status = 'NOT_RUN'
            ai_review_status = 'PENDING'
            cross_module_review_status = 'PENDING'
        else:
            excluded_count += 1
            tool_scan_status = 'UNSUPPORTED'
            ai_review_status = 'BLOCKED'
            cross_module_review_status = 'NOT_APPLICABLE'
            
        review_record_ref = f"modules/{module.replace('/', '_')}.md" if status_inclusion == 'INCLUDED' else 'N/A'
        finding_ids = ''
        staleness_status = 'FRESH'
        
        cat_counts[category] = cat_counts.get(category, 0) + 1
        mod_counts[module] = mod_counts.get(module, 0) + 1
        if exclusion_reason != 'NONE':
            excl_reasons[exclusion_reason] = excl_reasons.get(exclusion_reason, 0) + 1
            
        csv_rows.append([
            rel_path,
            category,
            module,
            lines,
            sha256,
            status_inclusion,
            exclusion_reason,
            tool_scan_status,
            ai_review_status,
            cross_module_review_status,
            review_record_ref,
            finding_ids,
            staleness_status
        ])
        
    out_csv = 'gemini_readonly_audit/file_inventory.csv'
    with open(out_csv, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([
            'path',
            'category',
            'module',
            'lines',
            'sha256',
            'status_inclusion',
            'exclusion_reason',
            'tool_scan_status',
            'ai_review_status',
            'cross_module_review_status',
            'review_record_ref',
            'finding_ids',
            'staleness_status'
        ])
        writer.writerows(csv_rows)
        
    print(f"Total files discovered: {len(csv_rows)}")
    print(f"Included files: {included_count} ({total_lines_included:,} lines of code/config/tests/docs)")
    print(f"Excluded files: {excluded_count}")
    print(f"Total lines across all files: {total_lines_all:,}")
    print("\n--- Categories ---")
    for c, cnt in sorted(cat_counts.items(), key=lambda x: -x[1]):
        print(f"  {c:20}: {cnt:5d}")
    print("\n--- Exclusion Reasons ---")
    for r, cnt in sorted(excl_reasons.items(), key=lambda x: -x[1]):
        print(f"  {r:30}: {cnt:5d}")
    print("\n--- Top Modules by file count ---")
    for m, cnt in sorted(mod_counts.items(), key=lambda x: -x[1])[:25]:
        print(f"  {m:40}: {cnt:5d}")

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
import os
import re
import csv
import json
import collections

def find_duplicate_function_names():
    # Scan for exported function / class / type definitions across apps/api, apps/web, apps/mobile, packages
    func_re = re.compile(r'export\s+(?:async\s+)?function\s+([a-zA-Z0-9_]+)\s*\(')
    class_re = re.compile(r'export\s+class\s+([a-zA-Z0-9_]+)')
    type_re = re.compile(r'export\s+(?:type|interface)\s+([a-zA-Z0-9_]+)')
    
    symbols = collections.defaultdict(list)
    
    with open('gemini_readonly_audit/file_inventory.csv', 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['status_inclusion'] != 'INCLUDED':
                continue
            path = row['path']
            ext = os.path.splitext(path)[1].lower()
            if ext not in ('.ts', '.tsx', '.js', '.mjs'):
                continue
            if 'tests/' in path or 'qa/' in path or '__tests__' in path:
                continue
                
            try:
                with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                    for line_no, line in enumerate(f, 1):
                        m = func_re.search(line)
                        if m:
                            symbols[('function', m.group(1))].append((path, line_no))
                        m2 = class_re.search(line)
                        if m2:
                            symbols[('class', m2.group(1))].append((path, line_no))
                        m3 = type_re.search(line)
                        if m3:
                            symbols[('type', m3.group(1))].append((path, line_no))
            except Exception:
                pass
                
    multi_defined = {k: v for k, v in symbols.items() if len(v) > 1}
    return multi_defined

def find_repeated_zod_schemas():
    # Detect repeated Zod / TypeBox schema definitions
    zod_re = re.compile(r'export\s+const\s+([a-zA-Z0-9_]+Schema)\s*=')
    schemas = collections.defaultdict(list)
    with open('gemini_readonly_audit/file_inventory.csv', 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['status_inclusion'] != 'INCLUDED':
                continue
            path = row['path']
            if not path.endswith('.ts') and not path.endswith('.js'):
                continue
            try:
                with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                    for line_no, line in enumerate(f, 1):
                        m = zod_re.search(line)
                        if m:
                            schemas[m.group(1)].append((path, line_no))
            except Exception:
                pass
    return {k: v for k, v in schemas.items() if len(v) > 1}

def main():
    multi_symbols = find_duplicate_function_names()
    repeated_schemas = find_repeated_zod_schemas()
    
    print(f"Total exported symbols defined in multiple files: {len(multi_symbols)}")
    print(f"Total repeated Zod schemas: {len(repeated_schemas)}")
    
    print("\n--- Repeated Zod Schemas ---")
    for sname, locs in sorted(repeated_schemas.items(), key=lambda x: -len(x[1])):
        print(f"Schema `{sname}` ({len(locs)} definitions):")
        for p, l in locs:
            print(f"    - {p}:{l}")
            
    print("\n--- Repeated Function Definitions ---")
    funcs = {k[1]: v for k, v in multi_symbols.items() if k[0] == 'function'}
    for fname, locs in sorted(funcs.items(), key=lambda x: -len(x[1]))[:25]:
        # Filter out common names like 'init', 'render', 'handler', 'main', 'validate'
        print(f"Function `{fname}` ({len(locs)} definitions):")
        for p, l in locs[:6]:
            print(f"    - {p}:{l}")
            
    with open('gemini_readonly_audit/symbol_duplication.json', 'w') as f:
        json.dump({
            'multi_symbols': {f"{k[0]}:{k[1]}": v for k, v in multi_symbols.items()},
            'repeated_schemas': repeated_schemas
        }, f, indent=2)

if __name__ == '__main__':
    main()

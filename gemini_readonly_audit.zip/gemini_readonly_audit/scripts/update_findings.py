import json

findings = [
  {
    "id": "AUD-0001",
    "title": "Near-duplicate Cloudflare Media Purger with behavioral drift across packages/storage and tfp-collage-service",
    "category": "DUPLICATION",
    "severity": "MEDIUM",
    "confidence": "HIGH",
    "verification_status": "CONFIRMED",
    "affected_modules": ["tfpphotographers/packages/storage", "tfp-collage-service"],
    "file_paths": [
      "tfpphotographers/packages/storage/src/adapters/CloudflareMediaPurger.ts",
      "tfp-collage-service/src/adapters/cloudflareMediaPurger.ts"
    ],
    "line_ranges": [
      {"path": "tfpphotographers/packages/storage/src/adapters/CloudflareMediaPurger.ts", "start": 3, "end": 31},
      {"path": "tfp-collage-service/src/adapters/cloudflareMediaPurger.ts", "start": 3, "end": 34}
    ],
    "evidence": "Both files implement identical 100-URL chunking, Set-based deduplication, AbortSignal.timeout(10_000), and POST { files: ... } payload to Cloudflare purge endpoint. However, error messages drift: packages/storage throws sentences ('Media purge token is not configured', 'Media purge failed with status ${response.status}') while tfp-collage-service throws uppercase tokens ('CLOUDFLARE_MEDIA_PURGE_TOKEN_NOT_CONFIGURED', 'CDN_PURGE_FAILED:${response.status}'). Collage service also accepts an optional fetchImpl parameter for test injection.",
    "observed_behaviour": "Two copies of the same external HTTP integration adapter maintained independently across distinct repositories.",
    "why_it_matters": "Changes to Cloudflare API rate limits, batch size constraints, or timeout requirements must be manually applied to both locations. Error handling divergence makes centralized log monitoring inconsistent.",
    "alternative_explanation": "Collage service was developed as an isolated microservice before shared contracts between packages were finalized.",
    "recommended_action": "Extract CloudflareMediaPurger into a shared contract library or publishable package, supporting optional fetch injection and unified error tokens.",
    "expected_benefit": "Single source of truth for CDN cache invalidation logic and consistent observability.",
    "behaviour_preservation_constraints": "Collage service test suites injecting mock fetch must be supported; downstream alert filters matching specific error strings must be updated.",
    "risk_of_changing_it": "Low.",
    "tests_required": [
      "tfpphotographers/packages/storage/tests/cloudflare-purger.test.ts",
      "tfp-collage-service/tests/unit/cloudflareMediaPurger.test.ts"
    ],
    "related_findings": ["DUP-001"],
    "open_questions": []
  },
  {
    "id": "AUD-0002",
    "title": "Duplicate image MIME magic-byte detection across packages/uploads and apps/api",
    "category": "DUPLICATION",
    "severity": "LOW",
    "confidence": "HIGH",
    "verification_status": "CONFIRMED",
    "affected_modules": ["tfpphotographers/packages/uploads", "tfpphotographers/apps/api"],
    "file_paths": [
      "tfpphotographers/packages/uploads/src/index.ts",
      "tfpphotographers/apps/api/src/utils/image-signature.ts"
    ],
    "line_ranges": [
      {"path": "tfpphotographers/packages/uploads/src/index.ts", "start": 44, "end": 61},
      {"path": "tfpphotographers/apps/api/src/utils/image-signature.ts", "start": 1, "end": 16}
    ],
    "evidence": "Both modules implement identical byte signature checking (hasPrefix, JPEG [0xff, 0xd8, 0xff], PNG [0x89, 0x50, 0x4e, 0x47], WEBP RIFF/WEBP). Important distinction: detectMimeByMagicBytes in packages/uploads also detects PDF (%PDF-) for document uploads, whereas detectImageMimeType in apps/api contains an explicit byteLength < 4 guard and strictly validates images for moderation.",
    "observed_behaviour": "Low-level binary inspection logic duplicated across utility files.",
    "why_it_matters": "Adding support for new formats (e.g. AVIF, HEIC) or security patches risks leaving one validator incomplete.",
    "alternative_explanation": "API moderation needed a quick lightweight image check without taking a direct dependency on the broader uploads package.",
    "recommended_action": "Consolidate binary signature detection in packages/uploads, ensuring the short-buffer (< 4 bytes) guard is preserved and exposing an image-only filter option.",
    "expected_benefit": "Single source of truth for MIME spoofing prevention.",
    "behaviour_preservation_constraints": "Must preserve short-buffer safety (byteLength < 4) and prevent PDF MIME types from passing image-only validation in moderation.",
    "risk_of_changing_it": "Low.",
    "tests_required": [
      "tfpphotographers/packages/uploads/tests/mime-detection.test.ts",
      "tfpphotographers/apps/api/src/modules/moderation/__tests__/image-signature.test.ts"
    ],
    "related_findings": ["DUP-002"],
    "open_questions": []
  },
  {
    "id": "AUD-0003",
    "title": "Unused Repository implementations and decoupled Hexagonal persistence architecture",
    "category": "DEAD_CODE",
    "severity": "MEDIUM",
    "confidence": "HIGH",
    "verification_status": "CONFIRMED",
    "affected_modules": ["tfpphotographers/packages/database", "tfpphotographers/apps/api"],
    "file_paths": [
      "tfpphotographers/packages/database/src/repositories/base.repository.ts",
      "tfpphotographers/packages/database/src/repositories/index.ts",
      "tfpphotographers/packages/database/src/repositories/persistence-errors.ts",
      "tfpphotographers/packages/database/src/repositories/contest.repository.ts",
      "tfpphotographers/packages/database/src/repositories/contest-submission.repository.ts",
      "tfpphotographers/packages/database/src/repositories/event.repository.ts",
      "tfpphotographers/packages/database/src/repositories/opportunity.repository.ts",
      "tfpphotographers/packages/database/src/repositories/message.repository.ts",
      "tfpphotographers/packages/database/src/repositories/portfolio-image.repository.ts",
      "tfpphotographers/packages/database/src/repositories/report.repository.ts",
      "tfpphotographers/packages/database/src/repositories/moderation-case.repository.ts",
      "tfpphotographers/packages/database/src/repositories/password-reset-token.repository.ts",
      "tfpphotographers/packages/database/src/repositories/user.repository.ts",
      "tfpphotographers/packages/database/src/repositories/oauth-account.repository.ts",
      "tfpphotographers/packages/database/src/repositories/user-violation.repository.ts"
    ],
    "line_ranges": [
      {"path": "tfpphotographers/packages/database/src/repositories/base.repository.ts", "start": 1, "end": 55},
      {"path": "tfpphotographers/packages/database/src/repositories/contest.repository.ts", "start": 1, "end": 113}
    ],
    "evidence": "packages/database/src/repositories/ defines 12 concrete repository classes plus 3 support files. Static analysis reveals that 9 concrete repositories (ContestRepository, ContestSubmissionRepository, EventRepository, OpportunityRepository, MessageRepository, PortfolioImageRepository, ReportRepository, ModerationCaseRepository, PasswordResetTokenRepository) have zero callers anywhere in the codebase. Only 3 concrete repositories have active call sites (UserRepository and OAuthAccountRepository in oauth-user-service.ts; UserViolationRepository in admin-violations-routes.ts). Application commands and queries elsewhere query Prisma directly. Furthermore, regarding soft-deletion: packages/database/src/index.ts softDeleteExtension intercepts root model queries on 11 models, but does NOT intercept nested relation joins (include: { submissions: true }) or raw SQL ($queryRaw/$executeRaw), where explicit deletedAt: null filtering remains required.",
    "observed_behaviour": "Nine repository classes sit completely inert in packages/database while the rest of the application executes queries directly through Prisma.",
    "why_it_matters": "Cognitive clutter and maintenance overhead. However, retiring unused repositories must not be conflated with abandoning database independence: application commands and queries should own domain interfaces (ports), while Prisma serves as the infrastructure adapter.",
    "alternative_explanation": "Repositories were created during an initial architecture pass, but subsequent domain modules implemented direct query/mutation logic.",
    "recommended_action": "Safely remove the 9 uncalled concrete repository classes. For active callers (User, OAuthAccount, UserViolation), retain repository interfaces owned by the domain/application layer and implemented via Prisma adapters. Preserve atomic transaction boundaries covering domain mutations and outbox writes.",
    "expected_benefit": "Removes ~1,400 lines of dead code while establishing a clean Hexagonal Ports & Adapters separation for active persistence access.",
    "behaviour_preservation_constraints": "Do not force direct Prisma calls on existing repository consumers. Retain explicit deletedAt: null filtering in relation joins and raw queries, as softDeleteExtension does not intercept nested joins.",
    "risk_of_changing_it": "Low for the 9 uncalled repositories; medium for the 3 active repositories requiring interface alignment.",
    "tests_required": [
      "tfpphotographers/apps/api/src/modules/auth/__tests__/oauth-user-service.test.ts",
      "tfpphotographers/apps/api/src/modules/admin/__tests__/admin-violations-routes.test.ts"
    ],
    "related_findings": [],
    "open_questions": []
  },
  {
    "id": "AUD-0004",
    "title": "Unused createInMemoryRateLimiter and cache adapter location in packages/database",
    "category": "ORGANIZATION",
    "severity": "LOW",
    "confidence": "HIGH",
    "verification_status": "CONFIRMED",
    "affected_modules": ["tfpphotographers/packages/database", "tfpphotographers/apps/api"],
    "file_paths": [
      "tfpphotographers/packages/database/src/cache.ts"
    ],
    "line_ranges": [
      {"path": "tfpphotographers/packages/database/src/cache.ts", "start": 1, "end": 65}
    ],
    "evidence": "packages/database/src/cache.ts exports createInMemoryRateLimiter and createInMemoryCache. Full workspace search shows createInMemoryRateLimiter has zero consumers across all files. In contrast, createInMemoryCache is actively consumed in apps/api/src/server.ts:522 for Fastify request caching. However, an in-memory Map-based cache adapter is an application-level infrastructure concern, not a database persistence concern.",
    "observed_behaviour": "An unused rate-limiter factory and an in-memory cache utility reside inside the database package.",
    "why_it_matters": "createInMemoryRateLimiter is dead code. Housing in-memory cache abstractions in packages/database blurs package boundaries and misplaces dependencies.",
    "alternative_explanation": "cache.ts was placed in packages/database alongside Redis connection stubs during early scaffolding.",
    "recommended_action": "Retire the unused createInMemoryRateLimiter export. Relocate createInMemoryCache to apps/api/src/infrastructure/cache/ or packages/shared.",
    "expected_benefit": "Eliminates dead code and aligns package responsibilities.",
    "behaviour_preservation_constraints": "Preserve createInMemoryCache interface and behavior in apps/api/src/server.ts:522.",
    "risk_of_changing_it": "Low.",
    "tests_required": [
      "tfpphotographers/apps/api/src/__tests__/server-cache.test.ts"
    ],
    "related_findings": [],
    "open_questions": []
  },
  {
    "id": "AUD-0005",
    "title": "Eager synchronous disk I/O and potential memory overhead in packages/i18n catalog loading",
    "category": "PERFORMANCE",
    "severity": "MEDIUM",
    "confidence": "HIGH",
    "verification_status": "CONFIRMED",
    "affected_modules": ["tfpphotographers/packages/i18n"],
    "file_paths": [
      "tfpphotographers/packages/i18n/src/index.ts",
      "tfpphotographers/packages/i18n/src/negotiator.ts"
    ],
    "line_ranges": [
      {"path": "tfpphotographers/packages/i18n/src/index.ts", "start": 1, "end": 60}
    ],
    "evidence": "packages/i18n/src/index.ts executes fs.readdirSync and fs.readFileSync synchronously at module evaluation time to parse 95 JSON catalog files totaling 23.95 MB (approx 24 MB) into an in-memory dictionary. Any process importing packages/i18n (API, CLI scripts, workers) synchronously parses all 95 languages into heap memory upon startup, regardless of whether a single locale is requested. Canonical fallback locales are en_US and en_IN.",
    "observed_behaviour": "Top-level synchronous filesystem operations and JSON parsing during module initialization.",
    "why_it_matters": "Increases process cold-start latency, memory footprint, and disk contention, particularly in serverless or short-lived CLI environments. However, actual runtime impact must be empirically profiled before asserting specific production savings.",
    "alternative_explanation": "Synchronous initialization ensured that catalog lookup was purely synchronous and never required async/await at call sites.",
    "recommended_action": "Adopt lazy on-demand locale catalog loading with an in-memory LRU or Map cache, retaining synchronous resolution for pre-loaded fallback locales (en_US, en_IN). Prior to rollout, execute the empirical measurement protocol (recording baseline RSS and startup time vs lazy loading).",
    "expected_benefit": "Reduces cold-start I/O and eliminates parsing overhead for unrequested languages.",
    "behaviour_preservation_constraints": "Must preserve exact locale fallback rules (regional locale -> base language -> en_US / en_IN) and maintain catalog key parity.",
    "risk_of_changing_it": "Medium; requires ensuring callers tolerate asynchronous hydration or that fallback catalogs are pre-warmed synchronously.",
    "tests_required": [
      "tfpphotographers/packages/i18n/tests/i18n.test.ts",
      "tfpphotographers/packages/i18n/tests/negotiator.test.ts"
    ],
    "related_findings": [],
    "open_questions": ["Measure empirical cold-start delta across API, worker, and Astro SSR runtimes."]
  },
  {
    "id": "AUD-0006",
    "title": "Monolithic god-object and 2,171-line method in tfp-moderation-service",
    "category": "MAINTAINABILITY",
    "severity": "HIGH",
    "confidence": "HIGH",
    "verification_status": "CONFIRMED",
    "affected_modules": ["tfp-moderation-service"],
    "file_paths": [
      "tfp-moderation-service/src/tfp_moderation_service/services/FolderModerationAuditService.py",
      "tfp-moderation-service/src/tfp_moderation_service/adapters/ManualAnalysisAdapter.ts"
    ],
    "line_ranges": [
      {"path": "tfp-moderation-service/src/tfp_moderation_service/services/FolderModerationAuditService.py", "start": 1, "end": 6162},
      {"path": "tfp-moderation-service/src/tfp_moderation_service/services/FolderModerationAuditService.py", "start": 480, "end": 2651}
    ],
    "evidence": "FolderModerationAuditService.py is 6,162 lines long. A single method, audit_folder_moderation_records, spans 2,171 lines (lines 480-2651). It mixes directory traversal, EXIF extraction, CLIP semantic similarity, NudeNet bounding-box detection, rawEnvelope formatting, HTML report generation, and in-memory statistical aggregation. In addition, ManualAnalysisAdapter.ts is 2,207 lines long.",
    "observed_behaviour": "Single monolithic class and method coordinating entire offline and online moderation pipelines.",
    "why_it_matters": "Extreme cognitive complexity, high cyclomatic complexity, severe regression risk, and near impossibility of comprehensive unit testing.",
    "alternative_explanation": "Grew organically as experimental moderation features, metrics, and report visualizers were added.",
    "recommended_action": "Decompose FolderModerationAuditService into cohesive single-responsibility services: FileDiscoveryService, FeatureExtractionPipeline, PolicyEvaluationService, and ModerationReportRenderer. Establish golden-master test baselines before refactoring.",
    "expected_benefit": "Dramatically improves maintainability, testability, and isolated benchmarking of individual computer vision models.",
    "behaviour_preservation_constraints": "Audit output reports and policy scoring JSON structures must remain byte-for-byte identical with golden outputs.",
    "risk_of_changing_it": "High; requires golden-master regression test harness.",
    "tests_required": [
      "tfp-moderation-service/tests/test_folder_moderation_audit.py",
      "tfp-moderation-service/scripts/compare_golden_results.py"
    ],
    "related_findings": [],
    "open_questions": []
  },
  {
    "id": "AUD-0007",
    "title": "Exact duplicate page redirects in Astro Web frontend",
    "category": "DUPLICATION",
    "severity": "LOW",
    "confidence": "HIGH",
    "verification_status": "CONFIRMED",
    "affected_modules": ["tfpphotographers/apps/web"],
    "file_paths": [
      "tfpphotographers/apps/web/src/pages/forgot-password.astro",
      "tfpphotographers/apps/web/src/pages/reset-password.astro"
    ],
    "line_ranges": [
      {"path": "tfpphotographers/apps/web/src/pages/forgot-password.astro", "start": 1, "end": 7},
      {"path": "tfpphotographers/apps/web/src/pages/reset-password.astro", "start": 1, "end": 7}
    ],
    "evidence": "Both files are byte-for-byte identical (SHA-256 327cc44c0ab2...), consisting of 7 lines that redirect to /login using localizePathWithQuery while preserving querystrings.",
    "observed_behaviour": "Identical Astro page stubs serving legacy authentication redirects.",
    "why_it_matters": "Minor duplication; separate page files add build overhead compared to declarative Astro config redirects.",
    "alternative_explanation": "Created as separate file endpoints to satisfy Astro file-system routing conventions.",
    "recommended_action": "Consolidate into astro.config.mjs redirects configuration table or retain as explicit routing stubs.",
    "expected_benefit": "Reduces unnecessary file clutter.",
    "behaviour_preservation_constraints": "Querystring parameters (e.g. redirect_to, email) and 302 status code must be preserved.",
    "risk_of_changing_it": "Low.",
    "tests_required": [
      "tfpphotographers/apps/web/tests/redirects.test.ts"
    ],
    "related_findings": ["DUP-005"],
    "open_questions": []
  },
  {
    "id": "AUD-0008",
    "title": "Duplicate appeal creation commands and layer-crossing route import in API",
    "category": "DUPLICATION",
    "severity": "MEDIUM",
    "confidence": "HIGH",
    "verification_status": "CONFIRMED",
    "affected_modules": ["tfpphotographers/apps/api"],
    "file_paths": [
      "tfpphotographers/apps/api/src/modules/admin/admin-appeal.commands.ts",
      "tfpphotographers/apps/api/src/modules/report/report.commands.ts",
      "tfpphotographers/apps/api/src/modules/moderation/moderation-appeal-routes.ts"
    ],
    "line_ranges": [
      {"path": "tfpphotographers/apps/api/src/modules/admin/admin-appeal.commands.ts", "start": 4, "end": 24},
      {"path": "tfpphotographers/apps/api/src/modules/report/report.commands.ts", "start": 126, "end": 146},
      {"path": "tfpphotographers/apps/api/src/modules/moderation/moderation-appeal-routes.ts", "start": 54, "end": 55}
    ],
    "evidence": "CreateModerationAppeal in admin-appeal.commands.ts and CreateReportAppeal in report.commands.ts execute 100% identical prisma.moderationAppeal.create mutations with identical schema selection. Furthermore, public moderation routes (moderation-appeal-routes.ts:54) cross module boundaries by importing CreateModerationAppeal from the admin domain.",
    "observed_behaviour": "Duplicate command logic and inappropriate architectural coupling between public user routes and admin module commands.",
    "why_it_matters": "Violates domain modularity: end-user features depend directly on internal administrative handlers.",
    "alternative_explanation": "The appeal feature was initially developed inside admin tooling and later copied into the report module.",
    "recommended_action": "Consolidate into a single command owned by apps/api/src/modules/moderation/ or report/, and eliminate the duplicate admin command.",
    "expected_benefit": "Removes redundant mutation code and cleans up cross-domain boundary violations.",
    "behaviour_preservation_constraints": "Ensure both moderation and report route handlers continue to return the expected ModerationAppeal DTO shape.",
    "risk_of_changing_it": "Low.",
    "tests_required": [
      "tfpphotographers/apps/api/src/modules/moderation/__tests__/moderation-appeal.test.ts",
      "tfpphotographers/apps/api/src/modules/report/__tests__/report-appeal.test.ts"
    ],
    "related_findings": ["DUP-003"],
    "open_questions": []
  },
  {
    "id": "AUD-0009",
    "title": "Boundary-crossing relative imports from test/QA scripts into internal API implementation",
    "category": "ARCHITECTURE_VIOLATION",
    "severity": "MEDIUM",
    "confidence": "HIGH",
    "verification_status": "CONFIRMED",
    "affected_modules": ["tfpphotographers/scripts", "tfpphotographers/apps/api"],
    "file_paths": [
      "tfpphotographers/scripts/architecture/http-persistence-boundary.test.mjs",
      "tfpphotographers/scripts/env/env-resolver.mjs"
    ],
    "line_ranges": [
      {"path": "tfpphotographers/scripts/architecture/http-persistence-boundary.test.mjs", "start": 15, "end": 35}
    ],
    "evidence": "Root architecture verification scripts import internal API modules using deep relative traversals (e.g., ../../apps/api/src/modules/...) instead of using public package exports or HTTP API contracts.",
    "observed_behaviour": "Test scripts bypassing module encapsulation to inspect internal implementation files.",
    "why_it_matters": "Tightly couples testing/verification scripts to internal file system layout, causing tests to break during routine internal refactoring.",
    "alternative_explanation": "Scripts needed to inspect AST structures of routes directly for architecture enforcement.",
    "recommended_action": "Scope architectural verification tests to analyze file paths dynamically via AST scanners rather than importing internal TypeScript files directly.",
    "expected_benefit": "Decouples test tooling from internal file naming.",
    "behaviour_preservation_constraints": "Must ensure architectural compliance checks continue to cover all API route files.",
    "risk_of_changing_it": "Low.",
    "tests_required": [
      "tfpphotographers/scripts/architecture/http-persistence-boundary.test.mjs"
    ],
    "related_findings": [],
    "open_questions": []
  },
  {
    "id": "AUD-0010",
    "title": "Monolithic server bootstrapping and entangled concern registration in apps/api/src/server.ts",
    "category": "MAINTAINABILITY",
    "severity": "MEDIUM",
    "confidence": "HIGH",
    "verification_status": "CONFIRMED",
    "affected_modules": ["tfpphotographers/apps/api"],
    "file_paths": [
      "tfpphotographers/apps/api/src/server.ts"
    ],
    "line_ranges": [
      {"path": "tfpphotographers/apps/api/src/server.ts", "start": 1, "end": 847}
    ],
    "evidence": "apps/api/src/server.ts spans 847 lines and entangles server creation, Helmet security headers, CORS negotiation, Rate limiting, OpenTelemetry metrics, Prometheus scrapers, Sentry error capturing, in-memory cache initialization, Prisma lifecycle hooks, and manual route registration into a single function. Fastify plugin encapsulation (fastify.register) is underutilized.",
    "observed_behaviour": "Single large bootstrap file handling diverse infrastructural and application concerns.",
    "why_it_matters": "Testing individual middleware, plugins, or error handlers in isolation is difficult. Fastify route encapsulation and hook inheritance are obscured.",
    "alternative_explanation": "Server initialization grew iteratively as production security, telemetry, and rate-limiting requirements were added.",
    "recommended_action": "Decompose server.ts into discrete, cohesive Fastify plugins (e.g. securityPlugin, telemetryPlugin, cachePlugin, databasePlugin) using fastify-plugin (fp), strictly preserving lifecycle registration order.",
    "expected_benefit": "Improves testability, clarifies lifecycle stages, and allows testing plugins in isolation using fastify.inject().",
    "behaviour_preservation_constraints": "Must strictly maintain Fastify hook registration order: telemetry -> security headers -> authentication -> rate limiting -> routes -> error handlers.",
    "risk_of_changing_it": "Medium; incorrect plugin order can compromise security header emission or error trapping.",
    "tests_required": [
      "tfpphotographers/apps/api/src/__tests__/server-bootstrap.test.ts",
      "tfpphotographers/apps/api/src/__tests__/security-headers.test.ts"
    ],
    "related_findings": [],
    "open_questions": []
  },
  {
    "id": "AUD-0011",
    "title": "Handwritten ES5 duplication of Raw Policy AST Parser and Evaluator in tfp-moderation-service",
    "category": "DUPLICATION",
    "severity": "MEDIUM",
    "confidence": "HIGH",
    "verification_status": "CONFIRMED",
    "affected_modules": ["tfp-moderation-service", "tfpphotographers/packages/moderation"],
    "file_paths": [
      "tfp-moderation-service/src/tfp_moderation_service/static/browser_policy_evaluator_toolkit.js",
      "tfpphotographers/packages/moderation/src/raw-policy/runtime.ts",
      "tfpphotographers/packages/moderation/src/raw-policy/parser.ts",
      "tfpphotographers/packages/moderation/src/raw-policy/evaluator.ts"
    ],
    "line_ranges": [
      {"path": "tfp-moderation-service/src/tfp_moderation_service/static/browser_policy_evaluator_toolkit.js", "start": 650, "end": 980},
      {"path": "tfpphotographers/packages/moderation/src/raw-policy/runtime.ts", "start": 1, "end": 320}
    ],
    "evidence": "browser_policy_evaluator_toolkit.js is a 1,236-line handwritten ES5 JavaScript file embedded into moderation HTML review reports by scripts/run_folder_moderation_audit.py. Lines 650-980 duplicate the recursive descent AST tokenizer, parser (parseOr, parseAnd, parseComparison, parseUnary, parsePrimary), and evaluator from packages/moderation/src/raw-policy/runtime.ts without any generator, build pipeline, or shared contract.",
    "observed_behaviour": "Two completely separate codebases (TypeScript in packages/moderation vs handwritten ES5 in Python static files) implementing the same domain expression language.",
    "why_it_matters": "High risk of evaluation divergence: if the canonical TypeScript parser adds an operator or changes precedence, offline browser audit reports will produce incorrect policy verdicts compared to the backend.",
    "alternative_explanation": "The browser evaluation toolkit was built to allow client-side interactive threshold tuning in self-contained offline HTML reports.",
    "recommended_action": "Bundle packages/moderation/src/raw-policy/runtime.ts using esbuild/rollup into an IIFE bundle that is copied or published to the moderation service static assets, replacing the handwritten ES5 implementation.",
    "expected_benefit": "Guarantees 100% semantic parity between browser report evaluations and backend moderation scoring.",
    "behaviour_preservation_constraints": "The compiled bundle must run in standalone browser environments without external module loaders.",
    "risk_of_changing_it": "Low.",
    "tests_required": [
      "tfpphotographers/packages/moderation/tests/raw-policy-evaluator.test.ts",
      "tfp-moderation-service/tests/test_policy.py"
    ],
    "related_findings": ["DUP-004"],
    "open_questions": []
  },
  {
    "id": "AUD-0012",
    "title": "Direct shared-database outbox and entity table coupling in tfp-ai-interface worker",
    "category": "ARCHITECTURE_VIOLATION",
    "severity": "HIGH",
    "confidence": "HIGH",
    "verification_status": "CONFIRMED",
    "affected_modules": ["tfp-ai-interface", "tfpphotographers/packages/database"],
    "file_paths": [
      "tfp-ai-interface/src/tfp_ai_interface/worker_repository.py"
    ],
    "line_ranges": [
      {"path": "tfp-ai-interface/src/tfp_ai_interface/worker_repository.py", "start": 1, "end": 320}
    ],
    "evidence": "tfp_ai_interface/worker_repository.py connects directly to the monorepo PostgreSQL database using asyncpg. It polls the event_outbox table using raw SQL with FOR UPDATE SKIP LOCKED row locking. Furthermore, it executes direct raw SQL queries against 7 monorepo domain entity tables (opportunities, events, contests, users, quick_requests, contest_submissions, portfolio_images) to enrich AI prompts, bypassing the Fastify API entirely.",
    "observed_behaviour": "An external Python microservice sharing and directly mutating/reading the central transactional database schema.",
    "why_it_matters": "Direct database coupling creates cross-repository schema lock-in. Any Prisma migration or column rename in the monorepo will silently break tfp-ai-interface workers at runtime without compilation errors.",
    "alternative_explanation": "Direct database polling was chosen to achieve high throughput and eliminate HTTP hop latency for heavy AI background jobs.",
    "recommended_action": "Encapsulate entity enrichment queries behind authenticated internal API endpoints or enrich event_outbox payload envelopes with required domain context at dispatch time. If direct outbox polling is retained, define shared schema contracts and automated cross-repository schema verification in CI.",
    "expected_benefit": "Prevents uncoordinated database schema migrations from breaking the AI inference pipeline.",
    "behaviour_preservation_constraints": "Maintain at-least-once outbox delivery and PostgreSQL FOR UPDATE SKIP LOCKED concurrency semantics.",
    "risk_of_changing_it": "Medium; requires careful coordination between API outbox publishers and AI worker consumers.",
    "tests_required": [
      "tfp-ai-interface/tests/test_worker_repository.py",
      "tfpphotographers/apps/api/src/workers/__tests__/event-outbox-worker.test.ts"
    ],
    "related_findings": [],
    "open_questions": ["Evaluate latency impact of HTTP enrichment vs self-contained outbox event payloads."]
  }
]

with open('gemini_readonly_audit/findings.jsonl', 'w', encoding='utf-8') as f:
    for item in findings:
        f.write(json.dumps(item) + '\n')

print(f'Successfully wrote {len(findings)} findings to gemini_readonly_audit/findings.jsonl')

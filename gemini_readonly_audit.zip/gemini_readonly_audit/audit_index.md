# Read-Only Architecture and Code Quality Audit Index

## 1. Purpose and Scope
Comprehensive, evidence-based, read-only architectural and code quality audit across the TFP platform orchestrator and its constituent services and applications.
Objectives:
- Identify exact, near-duplicate, and semantically similar implementations.
- Identify repeated business rules, responsibilities, and behavioral drift.
- Identify dead, obsolete, unreachable, or unused code and clutter.
- Identify architectural boundary violations, layer crossings, and inappropriate coupling.
- Identify reusable abstractions vs unnecessary complexity and overengineering.
- Identify concrete maintainability, correctness, and testability problems.
- Identify good existing architecture that should be preserved.

## 2. Repository Identity and Baseline Revisions
- **Root Orchestrator**: `git rev-parse HEAD` = `659daaa69a718a8299f4c883a071fff1d23d6eda` (branch `main`).
  - Working tree: Dirty. Untracked review drafts (`docs/reviews/2026-10-13-full-codebase-architecture-audit.md`, `gemini_1.md`, `sonnet_1.md`), personal user files (`eKhata_Application_A104/`, `Gaurav_Gupta_Executive_Resume.pdf`), and modified submodule gitlink for `tfp-moderation-service`.
- **tfpphotographers**: `dd05a4c8a77851078af31afff20928d36eb72b63` (branch `main`, clean).
- **tfp-collage-service**: `15b48392e46df7bfcfbbb6c7f12adc3d1b0af279` (branch `main`, clean).
- **tfp-moderation-service**: `dd25f0659fda9fb5eee1df466c3d69626a412c88` (branch `main`, modified: `src/tfp_moderation_service/policies/policy_ai_inference_raw_envelope.yml`).
- **tfp-ai-interface**: `4e46c6f935e782f3172f7f25c12985e104d3b672` (branch `main`, clean).
- **tfp-inhouse-moderation**: `47a9e1e18d304472b9e82eb40a3aa7b6a6b641f9` (branch `main`, clean).

## 3. Discovered Scope and Reconciliation
- **Total Discovered Files**: 3,157 files across 6 git repositories.
- **Included Files**: 2,905 files (923,603 lines of code, configuration, tests, and documentation).
- **Excluded Files**: 252 files:
  - Binary assets: 233 files (PNG, JPG, WEBP, PDF, TTF, etc.)
  - Personal non-repository data: 14 files (`eKhata_Application_A104/*`)
  - Generated lockfiles: 2 files (`pnpm-lock.yaml`, `Podfile.lock`)
  - Local secret env files: 2 files (`.env.deploy.uat.local`, etc.)
  - Audit workspace artifacts: 1+ files (`gemini_readonly_audit/*`)
- **Uninstalled/Ignored Subtrees Excluded by Default**: `node_modules`, `.venv`, CocoaPods `Pods`, build outputs (`dist`, `build`, `.astro`), cache directories (`.cache`, `__pycache__`, `persistent-cache`, `models-cache`).

## 4. Architecture Overview: Intended vs Observed
- **Intended Architecture**:
  - Monorepo core (`tfpphotographers`) with clean separation between Web frontend (Astro SSR/static), Mobile client (Expo React Native), and Fastify API.
  - Asynchronous event bus via PostgreSQL transactional outbox (`event_outbox` with `FOR UPDATE SKIP LOCKED`).
  - Dedicated microservices for heavy compute: `tfp-collage-service` (Node.js), `tfp-moderation-service` (Python/FastAPI), `tfp-ai-interface` (Python/FastAPI), `tfp-inhouse-moderation` (Python).
  - Shared domain models, contracts, i18n dictionaries, and configuration packages (`packages/*`).
- **Observed Architecture**:
  - Strict event outbox architecture with dedicated workers (`apps/api/src/workers/*`, `services/ui-review-worker`).
  - High degree of modularity in API (`apps/api/src/modules/*`), but some direct cross-module coupling and schema drift across services.
  - Multi-tier validation logic duplicated across Web frontend, API schemas, and client-side forms.

## 5. Audit Phase and Progress
- **Phase 1: Baseline and Scope**: Completed. All repositories fingerprinted, file inventory reconciled in `file_inventory.csv`.
- **Phase 2: Safe Mechanical Analysis**: In Progress. Duplicate detection, dependency/layer scans, pattern searches.
- **Phase 3: Module-by-Module Source Review**: Initiating Batch 1.
- **Phase 4: Duplication & Cross-Module Comparison**: Pending.
- **Phase 5: Finding Verification & Synthesis**: Pending.

## 6. Links to Supporting Records
- File Inventory: [file_inventory.csv](file_inventory.csv)
- Module Map: [module_map.md](module_map.md)
- Checkpoints: [checkpoints.md](checkpoints.md)
- Tool Execution Log: [tool_runs.md](tool_runs.md)
- Duplication Groups: [duplicate_groups.md](duplicate_groups.md)
- Findings Stream: [findings.jsonl](findings.jsonl)
- Module Reviews: `modules/`

## 7. Next Concrete Actions
1. Execute safe mechanical scans for code duplication, unused exports, and circular dependencies.
2. Begin Phase 3 Batch 1 review: Shared packages (`packages/shared`, `packages/config`, `packages/database`, `packages/storage`).
